# LumoAuth Guard for OpenClaw

`@lumoauth/openclaw` checks every tool call that your OpenClaw agent makes, before the tool runs.
Each call is allowed, sent to you for approval, or blocked.
Your policy is stored in LumoAuth, not in the conversation, so a prompt injection cannot change it.

The check runs in OpenClaw's own process, outside the model.
Nothing that the model reads or writes can switch it off: not web pages, not e-mails, not files, and not the model's own reasoning.

## Install

You need OpenClaw 2026.11.5 or later and a LumoAuth organization.

```sh
openclaw plugins install npm:@lumoauth/openclaw
openclaw lumoauth setup
```

The install command shows what the plugin registers and asks you to accept it.
A scripted install cannot answer that question, so it needs `--accept-capabilities`:

```sh
openclaw plugins install npm:@lumoauth/openclaw --accept-capabilities
```

`setup` takes you through four steps:

1. It asks for the address of your LumoAuth dashboard, for example `https://app.lumoauth.dev/orgs/acme/portal`.
2. It lists OpenClaw's tools and your MCP servers, and asks which preset to start from.
3. It creates a key for the agent. The private key stays on this machine.
4. It prints a link, a code and a key fingerprint. Open the link, check that the code and the fingerprint match your terminal, and approve the agent.

Setup then saves its settings, turns the plugin on in OpenClaw, runs a self-test, and lists what the agent may do without asking.
If a gateway is running, restart it once: `openclaw gateway restart`.

Setup also works without questions:

```sh
openclaw lumoauth setup --url https://app.lumoauth.dev/orgs/acme/portal --preset assistant --approvals auto --yes
```

Until setup finishes, the Guard blocks every tool call. It fails closed on purpose.

## What it protects

| Area | What the Guard does |
|---|---|
| Every tool call | Built-in tools, MCP tools and plugin tools are checked before they run. Each call is allowed, sent to you for approval, or blocked. |
| Its own integrity | The agent cannot read the Guard's key, change OpenClaw's or the Guard's settings, install or remove plugins, or run `openclaw plugins`, `openclaw config` or `openclaw lumoauth`. No setting, capability or approval removes these rules. |
| Secrets on disk | SSH keys, cloud credentials (`~/.aws`, `~/.azure`, `~/.config/gcloud`, `~/.kube`), package registry tokens, browser profiles and OpenClaw's credential store are blocked. `.env` files, `*.pem` and `*.key` files need your approval. The same rules apply to paths that MCP and plugin tools receive, such as a filesystem MCP server. |
| Persistence | Writing to shell start-up files (`~/.bashrc`, `~/.zshrc`), autostart entries, systemd user units and LaunchAgents needs your approval. So do crontab edits and `at` jobs. |
| Untrusted input | Some tools bring in text that other people wrote: web pages, search results, PDFs, images and messages from other people. After such a tool runs, actions that send data out need your approval for 30 minutes, even when they are allowed. |
| Memory and skills | While the session holds untrusted input, writing standing instructions needs approval. Creating or changing a skill always needs approval. File tools may read the skills installed in OpenClaw's state directory, but never change them. |
| Identity | The agent signs in to LumoAuth with its own key pair (`private_key_jwt`) and sender-constrained tokens (DPoP). No shared secret exists. |
| Stop switch | Suspend or delete the agent in LumoAuth, and every tool call stops within a minute. On the machine, `openclaw lumoauth lock` stops them at once. |
| Audit | Every decision becomes an entry in LumoAuth's audit log. Argument values never leave the machine; only a SHA-256 digest is sent. |
| OpenClaw's own settings | `openclaw lumoauth doctor` checks the sandbox, who may message the agent, an exposed gateway, file permissions and plaintext secrets, and says what to change. |

## How a call is checked

The Guard takes these steps for every call. The first one that applies gives the answer.

1. **Locked?** Blocked until you run `openclaw lumoauth unlock`.
2. **Not set up?** Blocked.
3. **Protected?** A call that touches the Guard, OpenClaw's configuration or a credential store is blocked. A call that touches a `.env` file or a start-up file asks you first.
4. **No confirmation from LumoAuth?** The call is blocked when the agent is suspended. It is also blocked when LumoAuth cannot confirm the agent's permissions for longer than the offline grace (5 minutes by default).
5. **Allowed?** The call's capability (for example `files:write`) is one that you granted the agent in LumoAuth. It runs, unless the session took in untrusted input and the call can send data out. Then it asks you.
6. **Not allowed?** It asks you. You can set it to block instead.

Each tool call maps to one capability:

- Built-in tools have a fixed capability: `read` is `files:read`, `exec` is `shell:exec`, `message` is `messages:send`.
- MCP tools get `mcp:<server>:<risk>:<tool>`, for example `mcp:github:read:list_issues`. The risk comes from the tool's name. You can grant `mcp:github:read:*` to allow every read-only GitHub tool.
- Other plugin tools get `tool:<name>`.

When a call is blocked, the model receives the reason.
If a capability is missing, the message tells the owner which one to add, with a link to the agent's page in LumoAuth.

## Presets

Setup sends LumoAuth a checklist of capabilities. The preset sets which boxes start ticked. You can change the ticks on the approval page, and later in LumoAuth.

| Preset | Allowed without asking |
|---|---|
| `observer` | Reading files, web search and pages, memory, sessions, media and skills. Read-only tools of each MCP server. |
| `assistant` (default) | Everything in `observer`, plus writing files and memory, goals and tasks, widgets, and generating media. Read and write tools of each MCP server. |
| `builder` | Everything in `assistant`, plus shell commands, code, background processes, sub-agents and the browser. |

No preset ticks sending messages, scheduled jobs, device control, stored secrets, host administration or skill changes. You grant those on purpose.

## Approvals

When a call needs approval, the Guard asks a person. The `approvals` setting chooses where:

| Setting | Where you approve |
|---|---|
| `auto` (default) | In the LumoAuth app on your phone, when the agent may act on your behalf. Otherwise, or when the app cannot be reached, in OpenClaw. |
| `lumoauth` | Only in the LumoAuth app. |
| `host` | In OpenClaw: the Control UI and chat channels that support approvals. |
| `off` | Nowhere: every call that needs approval is blocked. |

The approval shows the tool, the reason, the capability, the risk and up to five arguments.
Values of arguments named like passwords, tokens, keys or cookies are hidden.

In OpenClaw you can answer **Allow once**, **Allow always** or **Deny**.
**Allow always** is offered only for a capability that the agent was not granted.
It lasts for the current session and capability, and ends when OpenClaw restarts.
Calls that touch something protected, and calls after untrusted input, ask every time.

Runs with no one to answer, such as cron jobs, heartbeats and `openclaw agent` from a script, cannot show an approval.
OpenClaw blocks those calls. Grant the capability in LumoAuth if the run needs it.

## Commands

| Command | What it does |
|---|---|
| `openclaw lumoauth setup` | Connects this OpenClaw to LumoAuth (see [Install](#install)). Flags: `--url`, `--region us\|eu` with `--org`, `--preset`, `--approvals`, `--name`, `--yes`, `--force`. |
| `openclaw lumoauth status` | Shows the agent, its settings, its capabilities, the connection to LumoAuth, the receipts and recent decisions. `--json` prints JSON. `--offline` skips LumoAuth. |
| `openclaw lumoauth doctor` | Checks the Guard and OpenClaw's security settings. It changes nothing. `--json` prints JSON. |
| `openclaw lumoauth lock [reason]` | Blocks every tool call on this machine. |
| `openclaw lumoauth unlock` | Removes the lock. |
| `openclaw lumoauth reset` | Deletes the key and the settings on this machine. The agent stays in LumoAuth until you delete it there. |

In chat, the owner can send `/lumoauth` for a short status and `/lumoauth lock` to stop every tool call.
Unlocking works only in a terminal.

`openclaw security audit` does not show the Guard's checks: OpenClaw 2026.11.5 loads plugins there without running them.
Use `openclaw lumoauth doctor` instead.

The plugin ships the skill `lumoauth-guard`.
The skill tells the model what to do when a call waits for approval or is blocked.

## Configuration

The Guard keeps its files in `~/.lumoauth/guard/openclaw/`. Set `LUMOAUTH_GUARD_HOME` to use another directory.
The directory is readable only by your user (mode `0700`, files `0600`), and the agent cannot read or change it.

| File | Content |
|---|---|
| `config.json` | Settings (below). |
| `agent-key.pem` | The agent's private key (EC P-256). |
| `lock` | Present while the lock is on. |
| `status.json` | The last report of the running OpenClaw process, for `status`. |
| `receipts-queue.jsonl` | Audit receipts that were not delivered before OpenClaw exited. They are sent on the next start. |

Settings in `config.json` that you may change:

| Key | Default | Meaning |
|---|---|---|
| `approvals` | `auto` | Where a person approves: `auto`, `lumoauth`, `host` or `off`. |
| `onUngranted` | `ask` | A call without a granted capability asks (`ask`) or is blocked (`block`). |
| `decisionMode` | `local` | `local` checks capabilities on this machine and works on every plan. `server` asks LumoAuth's Ask API for each call. |
| `taint.enabled` | `true` | Ask before sending data out after untrusted input. |
| `taint.windowSeconds` | `1800` | How long a session counts as holding untrusted input. |
| `taint.escalate` | `["external"]` | Risks that need approval after untrusted input. The strict choice is `["external", "execute", "egress"]`. |
| `refreshSeconds` | `60` | How often the Guard reloads the agent's capabilities (30 to 600). |
| `offlineGraceSeconds` | `300` | How long the last capabilities stay valid while LumoAuth cannot be reached (0 to 3600). |
| `receipts` | `true` | Send an audit receipt for each decision. |
| `rememberApprovals` | `true` | Offer and honour **Allow always** for capabilities that are not granted, for the session. |
| `extraProtectedPaths` | `[]` | More paths that the agent may never read or write. |
| `allowPaths` | `[]` | Parts of OpenClaw's state directory that the agent may use. This never opens the Guard's files, OpenClaw's configuration or credential stores. |

A value out of range falls back to its default, and `status` reports it.
The Guard reads `config.json` again when it changes.

## Limits

The Guard is strong, but it is not a sandbox. Please read these limits.

- The Guard runs inside OpenClaw's process. An agent that may run shell commands or code runs them as your user. The Guard scans each command for protected paths and dangerous patterns, but a scan is a tripwire, not a sandbox. Combine the Guard with OpenClaw's sandbox (`agents.defaults.sandbox.mode`), which `doctor` recommends.
- The Guard checks only the calls that OpenClaw sends through its tool hook. In OpenClaw 2026.11.5 no other path is known.
- The risk of an MCP tool comes from its name. A malicious MCP server can give a tool a harmless name. Its calls still follow the rules for untrusted input and approvals.
- Taint and **Allow always** are kept in memory. They end when OpenClaw restarts.
- Plugins that run before the Guard can change a call's arguments. The Guard runs last, so it checks the arguments that the tool really gets. A plugin that blocks a call ends the check before the Guard runs.

## Uninstall

```sh
openclaw lumoauth reset --yes
openclaw plugins uninstall lumoauth
```

Then delete the agent in LumoAuth. `reset` prints the link to its page.

## Troubleshooting

**Every call is blocked with "not set up".** Run `openclaw lumoauth setup`. If you ran `reset`, run setup again.

**"LumoAuth cannot confirm this agent's permissions".** Run `openclaw lumoauth status`. It shows whether LumoAuth can be reached and whether it still accepts the agent's key. If the agent or its key was deleted in LumoAuth, run `openclaw lumoauth reset --yes` and then `setup`.

**A TLS error when LumoAuth uses a private certificate.** Start OpenClaw with `NODE_EXTRA_CA_CERTS=/path/to/ca.pem`, or with Node's `--use-system-ca`. The Guard has no switch to turn off certificate checks.

**An approval in the LumoAuth app times out.** OpenClaw ends a hook after its timeout. Setup sets `plugins.entries.lumoauth.hooks.timeouts.before_tool_call` to `180000` when app approvals are on. `doctor` checks it.

**"Plugin approval unavailable" in a script or cron job.** These runs have no one to answer. Grant the capability in LumoAuth, or run the task from a chat or the Control UI.

**OpenClaw says that it cannot verify where the plugin came from.** OpenClaw shows this for plugins that are not installed from ClawHub. Install from npm with `npm:@lumoauth/openclaw`. To load only the plugins that you chose, list them in `plugins.allow`.

## Development

```sh
npm install
npm run build          # TypeScript → dist/
npm test               # node --test: contract vectors, client, hooks, CLI
npm run sync-contract  # copy catalog, vectors and skill from ../agent-guard
```

To try the plugin in a real OpenClaw against a real LumoAuth, run `CA_CERT=/path/to/root.crt e2e/start.sh` (Docker; see the comments at the top of the script).

The behaviour follows the LumoAuth Guard contract (`SPEC.md` in the `agent-guard` repository).
The catalog, the test vectors and the skill are copied into `contract/` and `skills/`.
A test fails when the copy differs from `../agent-guard`.
The package has no runtime dependencies.

## License

MIT. See [LICENSE](LICENSE).
